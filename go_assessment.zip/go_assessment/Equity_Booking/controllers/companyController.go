package controllers

import (
	"encoding/json"
	"io"
	"log"
	"net/http"
	"training.com/stock_trading_app/models"
	"training.com/stock_trading_app/services"

	"github.com/gin-gonic/gin"
)

type CompaniesController struct {
	companiesService *services.CompaniesService
}

func NewCompaniesController(companiesService *services.CompaniesService) *CompaniesController {
	return &CompaniesController{
		companiesService: companiesService,
	}
}

func (rh CompaniesController) CreateCompany(ctx *gin.Context) {
	body, err := io.ReadAll(ctx.Request.Body)
	if err != nil {
		log.Println("Error while reading create company request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	var company models.Company
	err = json.Unmarshal(body, &company)
	if err != nil {
		log.Println("Error while unmarshaling create company request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	response, responseErr := rh.companiesService.CreateCompany(&company)
	if responseErr != nil {
		ctx.AbortWithStatusJSON(responseErr.Status, responseErr)
		return
	}

	ctx.JSON(http.StatusOK, response)
}

func (rh CompaniesController) UpdateCompany(ctx *gin.Context) {
	body, err := io.ReadAll(ctx.Request.Body)
	if err != nil {
		log.Println("Error while reading update company request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	var company models.Company
	err = json.Unmarshal(body, &company)
	if err != nil {
		log.Println("Error while unmarshaling update company request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	responseErr := rh.companiesService.UpdateCompany(&company)
	if responseErr != nil {
		ctx.AbortWithStatusJSON(responseErr.Status, responseErr)
		return
	}

	ctx.Status(http.StatusNoContent)
}

func (rh CompaniesController) DeleteCompany(ctx *gin.Context) {
	companyId := ctx.Param("id")

	responseErr := rh.companiesService.DeleteCompany(companyId)
	if responseErr != nil {
		ctx.AbortWithStatusJSON(responseErr.Status, responseErr)
		return
	}

	ctx.Status(http.StatusNoContent)
}

func (rh CompaniesController) GetCompany(ctx *gin.Context) {
	companyId := ctx.Param("id")

	response, responseErr := rh.companiesService.GetCompany(companyId)
	if responseErr != nil {
		ctx.JSON(responseErr.Status, responseErr)
		return
	}

	ctx.JSON(http.StatusOK, response)
}

func (rh CompaniesController) GetAllCompanies(ctx *gin.Context) {

	response, responseErr := rh.companiesService.GetAllCompanies()
	if responseErr != nil {
		ctx.JSON(responseErr.Status, responseErr)
		return
	}

	ctx.JSON(http.StatusOK, response)
}

func (rh CompaniesController) GetAllTradableCompanies(ctx *gin.Context) {

	tradingStatus := true
	response, responseErr := rh.companiesService.GetAllCompaniesByTradingStatus(tradingStatus);
	if responseErr != nil {
		ctx.JSON(responseErr.Status, responseErr)
		return
	}

	ctx.JSON(http.StatusOK, response)
}
