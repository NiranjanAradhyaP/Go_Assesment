package controllers

import (
	"encoding/json"
	"io"
	"log"
	"net/http"
	"training.com/stock_trading_app/models"
	"training.com/stock_trading_app/services"

	"github.com/gin-gonic/gin"
)

type AdminsController struct {
	adminsService *services.AdminsService
}

func NewAdminsController(adminsService *services.AdminsService) *AdminsController {
	return &AdminsController{
		adminsService: adminsService,
	}
}

func (rh AdminsController) Login(ctx *gin.Context) {
	body, err := io.ReadAll(ctx.Request.Body)
	if err != nil {
		log.Println("Error while reading create admin request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	var admin models.LoginCredentials
	err = json.Unmarshal(body, &admin)
	if err != nil {
		log.Println("Error while unmarshaling create admin request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	responseErr := rh.adminsService.LoginAdmin(admin.Email,admin.Password)
	if responseErr != nil {
		ctx.AbortWithStatusJSON(responseErr.Status, responseErr)
		return
	}

	ctx.JSON(http.StatusOK,nil)
}

// func (rh AdminsController) UpdateAdmin(ctx *gin.Context) {
// 	body, err := io.ReadAll(ctx.Request.Body)
// 	if err != nil {
// 		log.Println("Error while reading update admin request body", err)
// 		ctx.AbortWithError(http.StatusInternalServerError, err)
// 		return
// 	}

// 	var admin models.Admin
// 	err = json.Unmarshal(body, &admin)
// 	if err != nil {
// 		log.Println("Error while unmarshaling update admin request body", err)
// 		ctx.AbortWithError(http.StatusInternalServerError, err)
// 		return
// 	}

// 	responseErr := rh.adminsService.UpdateAdmin(&admin)
// 	if responseErr != nil {
// 		ctx.AbortWithStatusJSON(responseErr.Status, responseErr)
// 		return
// 	}

// 	ctx.Status(http.StatusNoContent)
// }

// func (rh AdminsController) DeleteAdmin(ctx *gin.Context) {
// 	adminId := ctx.Param("id")

// 	responseErr := rh.adminsService.DeleteAdmin(adminId)
// 	if responseErr != nil {
// 		ctx.AbortWithStatusJSON(responseErr.Status, responseErr)
// 		return
// 	}

// 	ctx.Status(http.StatusNoContent)
// }

// func (rh AdminsController) GetAdmin(ctx *gin.Context) {
// 	adminId := ctx.Param("id")

// 	response, responseErr := rh.adminsService.GetAdmin(adminId)
// 	if responseErr != nil {
// 		ctx.JSON(responseErr.Status, responseErr)
// 		return
// 	}

// 	ctx.JSON(http.StatusOK, response)
// }

