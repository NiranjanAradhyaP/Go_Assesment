package controllers

import (
	"encoding/json"
	"io"
	"log"
	"net/http"
	"training.com/stock_trading_app/models"
	"training.com/stock_trading_app/services"

	"github.com/gin-gonic/gin"
)

type CustomersController struct {
	customersService *services.CustomersService
}

func NewCustomersController(customersService *services.CustomersService) *CustomersController {
	return &CustomersController{
		customersService: customersService,
	}
}

func (cc CustomersController) SignUp(ctx *gin.Context) {
	body, err := io.ReadAll(ctx.Request.Body)
	if err != nil {
		log.Println("Error while reading create customer request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	var customer models.Customer
	err = json.Unmarshal(body, &customer)
	if err != nil {
		log.Println("Error while unmarshaling create customer request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	response, responseErr := cc.customersService.CreateCustomer(&customer)
	if responseErr != nil {
		ctx.AbortWithStatusJSON(responseErr.Status, responseErr)
		return
	}

	ctx.JSON(http.StatusOK, response)
}

func (cc CustomersController) Login(ctx *gin.Context) {
	body, err := io.ReadAll(ctx.Request.Body)
	if err != nil {
		log.Println("Error while reading create customer request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	var customer models.LoginCredentials
	err = json.Unmarshal(body, &customer)
	if err != nil {
		log.Println("Error while unmarshaling create customer request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	responseErr := cc.customersService.LoginCustomer(customer.Email,customer.Password)
	if responseErr != nil {
		ctx.AbortWithStatusJSON(responseErr.Status, responseErr)
		return
	}

	ctx.JSON(http.StatusOK,nil)
}