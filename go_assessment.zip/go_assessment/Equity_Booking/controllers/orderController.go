package controllers

import (
	"encoding/json"
	"io"
	"log"
	"net/http"
	"training.com/stock_trading_app/models"
	"training.com/stock_trading_app/services"

	"github.com/gin-gonic/gin"
)

type OrdersController struct {
	ordersService *services.OrderService
}

func NewOrdersController(ordersService *services.OrderService) *OrdersController {
	return &OrdersController{
		ordersService: ordersService,
	}
}

func (rh OrdersController) CreateOrder(ctx *gin.Context) {
	body, err := io.ReadAll(ctx.Request.Body)
	if err != nil {
		log.Println("Error while reading create company request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	var company models.Order
	err = json.Unmarshal(body, &company)
	if err != nil {
		log.Println("Error while unmarshaling create company request body", err)
		ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	response, responseErr := rh.ordersService.CreateOrder(&company)
	if responseErr != nil {
		ctx.AbortWithStatusJSON(responseErr.Status, responseErr)
		return
	}

	ctx.JSON(http.StatusOK, response)
}