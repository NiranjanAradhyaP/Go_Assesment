package server

import (
	"database/sql"
	"log"

	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"training.com/stock_trading_app/controllers"
	"training.com/stock_trading_app/repositories"
	"training.com/stock_trading_app/services"
)

type HttpServer struct {
	config              *viper.Viper
	router              *gin.Engine
	customersController *controllers.CustomersController
	adminsController    *controllers.AdminsController
	companiesController *controllers.CompaniesController
	ordersController    *controllers.OrdersController
}

func InitHttpServer(config *viper.Viper, dbHandler *sql.DB) HttpServer {
	customersRepository := repositories.NewCustomersRepository(dbHandler)
	customersService := services.NewCustomersService(customersRepository)
	customersController := controllers.NewCustomersController(customersService)

	adminsRepository := repositories.NewAdminsRepository(dbHandler)
	adminsService := services.NewAdminsService(adminsRepository)
	adminsController := controllers.NewAdminsController(adminsService)

	companiesRepository := repositories.NewCompaniesRepository(dbHandler)
	companiesService := services.NewCompaniesService(companiesRepository)
	companiesController := controllers.NewCompaniesController(companiesService)

	ordersRepository := repositories.NewOrdersRepository(dbHandler)
	ordersService := services.NewOrderService(ordersRepository, customersRepository)
	ordersController := controllers.NewOrdersController(ordersService)

	router := gin.Default()

	router.POST("/customer/sign_up", customersController.SignUp)
	router.POST("/customer/login", customersController.Login)
	router.POST("/admin/login", adminsController.Login)
	router.POST("/admin/stocks", companiesController.CreateCompany)
	router.DELETE("/admin/stocks", companiesController.DeleteCompany)
	router.GET("/admin/stocks", companiesController.GetAllCompanies)
	router.GET("/customer/stocks", companiesController.GetAllTradableCompanies)
	router.POST("/customer/orders", ordersController.CreateOrder)

	return HttpServer{
		config:              config,
		router:              router,
		customersController: customersController,
	}
}

func (hs HttpServer) Start() {
	err := hs.router.Run(hs.config.GetString("http.server_address"))
	if err != nil {
		log.Fatalf("Error while starting HTTP server: %v", err)
	}
}
