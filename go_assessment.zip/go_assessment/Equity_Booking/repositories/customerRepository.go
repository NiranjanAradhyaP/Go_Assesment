package repositories

import (
	"database/sql"
	"fmt"
	"net/http"
	"strconv"
	"training.com/stock_trading_app/models"
)

type CustomersRepository struct {
	dbHandler   *sql.DB
	transaction *sql.Tx
}

func NewCustomersRepository(dbHandler *sql.DB) *CustomersRepository {
	return &CustomersRepository{
		dbHandler: dbHandler,
	}
}

func (rr CustomersRepository) CreateCustomer(customer *models.Customer) (*models.Customer, *models.ResponseError) {
	query := `
    INSERT INTO customers (first_name, last_name, email, password_string, mobile_number,pan_number,demat_account_balance)
    VALUES (?, ?, ?, ?, ?, ?,?)`

	res, err := rr.dbHandler.Exec(query, customer.FirstName, customer.LastName, customer.Email, customer.Password, customer.MobileNumber, customer.PANNumber, customer.DematAccountBalance)

	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	customerId, err := res.LastInsertId()
	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	return &models.Customer{
		ID:                  strconv.FormatInt(customerId, 10),
		Email:               customer.Email,
		Password:            customer.Password,
		FirstName:           customer.FirstName,
		LastName:            customer.LastName,
		MobileNumber:        customer.MobileNumber,
		PANNumber:           customer.PANNumber,
		DematAccountBalance: customer.DematAccountBalance,
	}, nil
}

func (rr CustomersRepository) GetCustomerByEmail(reqEmail string) (*models.Customer, *models.ResponseError) {
	fmt.Println(reqEmail)
	query := `
		SELECT *
		FROM customers
		WHERE email = ?`

	rows, err := rr.dbHandler.Query(query, reqEmail)
	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	defer rows.Close()

	var id, firstName, lastName, email, password, mobileNumber, panNumber string
	var isActive bool
	var dematAccountBalance float64
	for rows.Next() {
		err := rows.Scan(&id, &email, &password, &firstName, &lastName, &mobileNumber, &isActive, &panNumber,&dematAccountBalance)
		if err != nil {
			return nil, &models.ResponseError{
				Message: err.Error(),
				Status:  http.StatusInternalServerError,
			}
		}
	}

	if rows.Err() != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	return &models.Customer{
		ID:           id,
		Email:        email,
		Password:     password,
		FirstName:    firstName,
		LastName:     lastName,
		MobileNumber: mobileNumber,
		IsActive:     isActive,
		PANNumber:    panNumber,
		DematAccountBalance: dematAccountBalance,
	}, nil
}
