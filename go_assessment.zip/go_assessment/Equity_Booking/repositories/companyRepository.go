package repositories

import (
	"database/sql"
	"fmt"
	"net/http"
	"strconv"
	"time"
	"training.com/stock_trading_app/models"
)

type CompaniesRepository struct {
	dbHandler   *sql.DB
	transaction *sql.Tx
}

func NewCompaniesRepository(dbHandler *sql.DB) *CompaniesRepository {
	return &CompaniesRepository{
		dbHandler: dbHandler,
	}
}

func (rr CompaniesRepository) CreateCompany(company *models.Company) (*models.Company, *models.ResponseError) {
	query := `
    INSERT INTO companies (registered_name, email, mobile_number, address, stock_price)
    VALUES (?, ?, ?, ?, ?)`

	res, err := rr.dbHandler.Exec(query, company.RegisteredName, company.Email, company.MobileNumber, company.Address, company.StockPrice)

	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	companyId, err := res.LastInsertId()
	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	return &models.Company{
		ID:             strconv.FormatInt(companyId, 10),
		RegisteredName: company.RegisteredName,
		Email:          company.Email,
		MobileNumber:   company.MobileNumber,
		Address:        company.Address,
		CreatedBy:      company.CreatedBy,
		ModifiedAt:     company.ModifiedAt,
		StockPrice:     company.StockPrice,
		IsTradable:     company.IsTradable,
	}, nil

}

func (rr CompaniesRepository) UpdateCompany(company *models.Company) *models.ResponseError {
	query := `
    UPDATE companies
    SET
        registered_name = ?,
        email = ?,
        mobile_number = ?,
        address = ?,
        modified_at = ?,
        stock_price = ?,
        is_tradable = ?
    WHERE id = ?`

	res, err := rr.dbHandler.Exec(query,
		company.RegisteredName,
		company.Email,
		company.MobileNumber,
		company.Address,
		time.Now(),
		company.StockPrice,
		company.IsTradable,
		company.ID)

	if err != nil {
		return &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	rowsAffected, err := res.RowsAffected()
	if err != nil {
		return &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	if rowsAffected == 0 {
		return &models.ResponseError{
			Message: "Company not found",
			Status:  http.StatusNotFound,
		}
	}

	return nil

}

func (rr CompaniesRepository) DeleteCompany(companyId string) *models.ResponseError {
	query := `UPDATE companies SET is_active = FALSE WHERE id = ?`

	res, err := rr.dbHandler.Exec(query, companyId)
	if err != nil {
		return &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	rowsAffected, err := res.RowsAffected()
	if err != nil {
		return &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	if rowsAffected == 0 {
		return &models.ResponseError{
			Message: "Company not found",
			Status:  http.StatusNotFound,
		}
	}

	return nil
}

func (rr CompaniesRepository) GetAllCompanies() ([]*models.Company, *models.ResponseError) {
	query := `
	SELECT *
	FROM companies`

	rows, err := rr.dbHandler.Query(query)
	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	defer rows.Close()

	companies, utilErr := rr.getCompaniesFromRows(rows)
	if utilErr != nil {
		return nil, utilErr
	}

	if rows.Err() != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	return companies, nil
}

func (rr CompaniesRepository) GetCompany(companyId string) (*models.Company, *models.ResponseError) {
	fmt.Println(companyId)
	query := `
		SELECT *
		FROM companies
		WHERE id = ?`

	rows, err := rr.dbHandler.Query(query, companyId)
	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	defer rows.Close()

	var id, registeredName, email, mobileNumber, address, createdBy string
	var createdAt, modifiedAt time.Time
	var stockPrice float32
	var isTradable bool

	for rows.Next() {
		err := rows.Scan(&id, &registeredName, &email, &mobileNumber, &address, &createdBy, &modifiedAt, &stockPrice, &isTradable,&createdAt)
		if err != nil {
			return nil, &models.ResponseError{
				Message: err.Error(),
				Status:  http.StatusInternalServerError,
			}
		}
	}

	if rows.Err() != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	return &models.Company{
		ID:             id,
		RegisteredName: registeredName,
		Email:          email,
		MobileNumber:   mobileNumber,
		Address:        address,
		CreatedBy:      createdBy,
		ModifiedAt:     modifiedAt,
		StockPrice:     stockPrice,
		IsTradable:     isTradable,
		CreatedAt:      createdAt,
	}, nil
}

func (rr CompaniesRepository) GetAllCompaniesByTradingStatus(status bool) ([]*models.Company, *models.ResponseError) {
	query := `
	SELECT *
	FROM companies WHERE is_tradable = ?`

	rows, err := rr.dbHandler.Query(query,status)
	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	defer rows.Close()

	companies, utilErr := rr.getCompaniesFromRows(rows)
	if utilErr != nil {
		return nil, utilErr
	}

	if rows.Err() != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	return companies, nil
}

func (cr CompaniesRepository) getCompaniesFromRows(rows *sql.Rows) ([]*models.Company, *models.ResponseError) {
	companies := make([]*models.Company, 0)
	var id, registeredName, email, mobileNumber, address, createdBy string
	var createdAt, modifiedAt time.Time
	var stockPrice float32
	var isTradable bool

	for rows.Next() {
		err := rows.Scan(&id, &registeredName, &email, &mobileNumber, &address, &createdBy, &modifiedAt, &stockPrice, &isTradable, &createdAt)
		if err != nil {
			return nil, &models.ResponseError{
				Message: err.Error(),
				Status:  http.StatusInternalServerError,
			}
		}

		company := &models.Company{
			ID:             id,
			RegisteredName: registeredName,
			Email:          email,
			MobileNumber:   mobileNumber,
			Address:        address,
			CreatedBy:      createdBy,
			CreatedAt:      createdAt,
			ModifiedAt:     modifiedAt,
			StockPrice:     stockPrice,
			IsTradable:     isTradable,
		}

		companies = append(companies, company)
	}

	return companies, nil

}
