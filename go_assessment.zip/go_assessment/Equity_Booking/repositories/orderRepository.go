package repositories

import (
	"context"
	"database/sql"
	"net/http"
	"training.com/stock_trading_app/models"
)

type OrderRepository struct {
	dbHandler *sql.DB
}

func NewOrdersRepository(dbHandler *sql.DB) *OrderRepository {
	return &OrderRepository{
		dbHandler: dbHandler,
	}
}


func (or *OrderRepository) CreateOrder(order *models.Order) (*models.Order, *models.ResponseError) {

	totalPrice := float64(order.Quantity) * order.Price
	query := `
		INSERT INTO orders (user_id, company_id, quantity, price, side, status, created_at, modified_at,amount)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
	
	ctx := context.Background()
	_, err := or.dbHandler.ExecContext(ctx, query,
		order.UserID,
		order.CompanyID,
		order.Quantity,
		order.Price,
		order.Side,
		order.Status,
		order.CreatedAt,
		order.ModifiedAt,
		totalPrice,
	)
	if err != nil {
		return nil,  &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	return order, nil
}
