package repositories

import (
	"database/sql"
	"fmt"
	"net/http"
	"training.com/stock_trading_app/models"
	"strconv"
	"time"
)

type AdminsRepository struct {
	dbHandler   *sql.DB
	transaction *sql.Tx
}

func NewAdminsRepository(dbHandler *sql.DB) *AdminsRepository {
	return &AdminsRepository{
		dbHandler: dbHandler,
	}
}

func (rr AdminsRepository) CreateAdmin(admin *models.Admin) (*models.Admin, *models.ResponseError) {
	query := `
    INSERT INTO admins (first_name, last_name, email, password_string, mobile_number)
    VALUES (?, ?, ?, ?, ?, ?)`
    
	res, err := rr.dbHandler.Exec(query, admin.FirstName, admin.LastName, admin.Email, admin.Password, admin.MobileNumber)

	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	adminId, err := res.LastInsertId()
	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	return &models.Admin{
		ID:        	  strconv.FormatInt(adminId, 10),
		Email:		  admin.Email,
		Password:     admin.Password,	
		FirstName:    admin.FirstName,
		LastName:     admin.LastName,
		MobileNumber: admin.MobileNumber,
	}, nil
}

// func (rr AdminsRepository) UpdateAdmin(admin *models.Admin) *models.ResponseError {
// 	query := `
// 		UPDATE admins
// 		SET
// 			first_name = ?,
// 			last_name = ?,
// 			age = ?,
// 			country = ?
// 		WHERE id = ?`

// 	res, err := rr.dbHandler.Exec(query, admin.FirstName, admin.LastName, admin.Age, admin.Country, admin.ID)
// 	if err != nil {
// 		return &models.ResponseError{
// 			Message: err.Error(),
// 			Status:  http.StatusInternalServerError,
// 		}
// 	}

// 	rowsAffected, err := res.RowsAffected()
// 	if err != nil {
// 		return &models.ResponseError{
// 			Message: err.Error(),
// 			Status:  http.StatusInternalServerError,
// 		}
// 	}

// 	if rowsAffected == 0 {
// 		return &models.ResponseError{
// 			Message: "Admin not found",
// 			Status:  http.StatusNotFound,
// 		}
// 	}

// 	return nil
// }


// func (rr AdminsRepository) DeleteAdmin(adminId string) *models.ResponseError {
// 	query := `UPDATE admins SET is_active = FALSE WHERE id = ?`

// 	res, err := rr.dbHandler.Exec(query, adminId)
// 	if err != nil {
// 		return &models.ResponseError{
// 			Message: err.Error(),
// 			Status:  http.StatusInternalServerError,
// 		}
// 	}

// 	rowsAffected, err := res.RowsAffected()
// 	if err != nil {
// 		return &models.ResponseError{
// 			Message: err.Error(),
// 			Status:  http.StatusInternalServerError,
// 		}
// 	}

// 	if rowsAffected == 0 {
// 		return &models.ResponseError{
// 			Message: "Admin not found",
// 			Status:  http.StatusNotFound,
// 		}
// 	}

// 	return nil
// }

func (rr AdminsRepository) GetAdminByEmail(reqEmail string) (*models.Admin, *models.ResponseError) {
	fmt.Println(reqEmail)
	query := `
		SELECT *
		FROM admins
		WHERE email = ?`

	rows, err := rr.dbHandler.Query(query, reqEmail)
	if err != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	defer rows.Close()

	var id, firstName, lastName,email,password,mobileNumber string
	var createdAt time.Time
	var isActive bool
	for rows.Next() {
		err := rows.Scan(&id,&email,&password, &firstName, &lastName, &mobileNumber,&createdAt, &isActive)
		if err != nil {
			return nil, &models.ResponseError{
				Message: err.Error(),
				Status:  http.StatusInternalServerError,
			}
		}
	}

	if rows.Err() != nil {
		return nil, &models.ResponseError{
			Message: err.Error(),
			Status:  http.StatusInternalServerError,
		}
	}

	// createdAtTime,err := time.Parse("2024-10-05 11:48:28",createdAt)
	// if(err!=nil){
	// }

	return &models.Admin{
		ID:           id,
		Email:		  email,
		Password:     password,	
		FirstName:    firstName,
		LastName:     lastName,
		MobileNumber: mobileNumber,
		CreatedAt:    createdAt,
		IsActive:     isActive,
	}, nil
}
