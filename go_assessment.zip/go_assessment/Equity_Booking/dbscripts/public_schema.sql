CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_string VARCHAR(255) NOT NULL,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    mobile_number VARCHAR(20) UNIQUE,
    is_active BOOL DEFAULT TRUE,
    pan_number VARCHAR(255) UNIQUE NOT NULL
    demat_account_balance DECIMAL(15,2)
);

CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    mobile_number VARCHAR(20) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOL DEFAULT TRUE
);

CREATE TABLE companies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    registered_name VARCHAR(255) UNIQUE NOT NULL,
    mobile_number VARCHAR(20), 
    address TEXT,
    created_by VARCHAR(128)
    created_at TIMESTAMP DEFAULT current_timestamp,
    modified_at TIMESTAMP DEFAULT current_timestamp,
    is_active BOOL DEFAULT TRUE
);

CREATE TABLE stocks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT REFERENCES companies(id),
    price FLOAT NOT NULL,
    date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOL DEFAULT TRUE
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) REFERENCES users(email),
    company_id INT REFERENCES companies(id),
    quantity INT NOT NULL,
    price FLOAT NOT NULL,
    order_type VARCHAR(20), -- e.g., "buy" or "sell"
    status VARCHAR(20), -- e.g., "pending", "completed"
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOL DEFAULT TRUE
);



