package models

import "time"

type Order struct {
	UserID     string    `json:"user_id" db:"user_id"`
	CompanyID  string    `json:"company_id" db:"company_id"`
	Quantity   int       `json:"quantity" db:"quantity"`
	Price      float64   `json:"price" db:"price"`
	Side       string    `json:"side" db:"side"`
	Status     string    `json:"status" db:"status"`
	CreatedAt  time.Time `json:"created_at" db:"created_at"`
	ModifiedAt time.Time `json:"modified_at" db:"modified_at"`
	Amount     float64	 `json:"amount" db:"amount"`
}
