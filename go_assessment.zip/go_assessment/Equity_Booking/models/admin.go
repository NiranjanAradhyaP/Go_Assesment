package models

import "time"

type Admin struct {
	ID           string    `json:"id" db:"id"`
	Email        string    `json:"email" db:"email" binding:"required,email"`
	Password     string    `json:"password" db:"password" binding:"required"`
	FirstName    string    `json:"first_name" db:"first_name" binding:"required"`
	LastName     string    `json:"last_name" db:"last_name" binding:"required"`
	MobileNumber string    `json:"mobile_number" db:"mobile_number"`
	CreatedAt    time.Time `json:"created_at" db:"created_at"`
	IsActive     bool      `json:"is_active" db:"is_active"`
}
