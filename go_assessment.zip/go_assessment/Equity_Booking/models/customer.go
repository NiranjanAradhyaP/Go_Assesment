package models


type Customer struct {
    ID           string    `json:"id" db:"id"`
    Email        string    `json:"email" db:"email" binding:"required,email"`
    Password     string    `json:"password" db:"password" binding:"required"`
    FirstName    string    `json:"first_name" db:"first_name" binding:"required"`
    LastName     string    `json:"last_name" db:"last_name" binding:"required"`
    MobileNumber string    `json:"mobile_number" db:"mobile_number"`
    PANNumber    string    `json:"pan_number" db:"pan_number" binding:"required"`
    IsActive     bool      `json:"is_active" db:"is_active"`
    DematAccountBalance float64 `json:"demat_account_balance" db:"demat_account_balance"`
}
