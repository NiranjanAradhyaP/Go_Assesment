package services

import (
	"net/http"
	"training.com/stock_trading_app/models"
	"training.com/stock_trading_app/repositories"
)

type OrderService struct {
	orderRepository   *repositories.OrderRepository
	customerRepository *repositories.CustomersRepository
}

func NewOrderService(orderRepo *repositories.OrderRepository, customerRepo *repositories.CustomersRepository) *OrderService {
	return &OrderService{
		orderRepository:   orderRepo,
		customerRepository: customerRepo,
	}
}

func (os *OrderService) CreateOrder(order *models.Order) (*models.Order, *models.ResponseError) {
	if order.UserID == "" || order.CompanyID == "" || order.Quantity <= 0 || order.Price <= 0 {
		return nil, &models.ResponseError{
			Message: "Invalid order details",
			Status:  http.StatusBadRequest,
		}
	}

	customer, err := os.customerRepository.GetCustomerByEmail(order.UserID)
	if err != nil {
		return nil, err
	}

	balance := customer.DematAccountBalance

	totalPrice := float64(order.Quantity) * order.Price

	if balance < totalPrice {
		return nil, &models.ResponseError{
			Message: "Insufficient balance in demat account",
			Status:  http.StatusBadRequest,
		}
	}

	order.Status = "Pending"

	createdOrder, err := os.orderRepository.CreateOrder(order)
	if err != nil {
		return nil, err
	}

	return createdOrder, nil
}
