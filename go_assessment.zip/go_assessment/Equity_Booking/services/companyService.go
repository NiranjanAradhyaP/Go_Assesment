package services

import (
	"net/http"
	"training.com/stock_trading_app/models"
	"training.com/stock_trading_app/repositories"
)

type CompaniesService struct {
	companiesRepository *repositories.CompaniesRepository
}

func NewCompaniesService(companiesRepository *repositories.CompaniesRepository) *CompaniesService {
	return &CompaniesService{
		companiesRepository: companiesRepository,
	}
}

func (cs CompaniesService) CreateCompany(company *models.Company) (*models.Company, *models.ResponseError) {
	responseErr := validateCompany(company)
	if responseErr != nil {
		return nil, responseErr
	}

	return cs.companiesRepository.CreateCompany(company)
}

func (cs CompaniesService) UpdateCompany(company *models.Company) *models.ResponseError {
	responseErr := validateCompanyId(company.ID)
	if responseErr != nil {
		return responseErr
	}

	responseErr = validateCompany(company)
	if responseErr != nil {
		return responseErr
	}

	return cs.companiesRepository.UpdateCompany(company)
}

func (cs CompaniesService) DeleteCompany(companyId string) *models.ResponseError {
	responseErr := validateCompanyId(companyId)
	if responseErr != nil {
		return responseErr
	}

	return cs.companiesRepository.DeleteCompany(companyId)
}

func (cs CompaniesService) GetCompany(companyId string) (*models.Company, *models.ResponseError) {
	responseErr := validateCompanyId(companyId)
	if responseErr != nil {
		return nil, responseErr
	}

	company, responseErr := cs.companiesRepository.GetCompany(companyId)
	if responseErr != nil {
		return nil, responseErr
	}

	return company, nil
}

func (cs CompaniesService) GetAllCompanies() ([]*models.Company, *models.ResponseError) {
	companies, responseErr := cs.companiesRepository.GetAllCompanies()
	if responseErr != nil {
		return nil, responseErr
	}

	return companies, nil
}

func (cs CompaniesService) GetAllCompaniesByTradingStatus(status bool) ([]*models.Company, *models.ResponseError) {
	companies, responseErr := cs.companiesRepository.GetAllCompaniesByTradingStatus(status)
	if responseErr != nil {
		return nil, responseErr
	}

	return companies, nil
}


func validateCompany(company *models.Company) *models.ResponseError {
	if company.RegisteredName == "" {
		return &models.ResponseError{
			Message: "Invalid first name",
			Status:  http.StatusBadRequest,
		}
	}

	return nil
}

func validateCompanyId(companyId string) *models.ResponseError {
	if companyId == "" {
		return &models.ResponseError{
			Message: "Invalid company ID",
			Status:  http.StatusBadRequest,
		}
	}

	return nil
}
