package services

import (
	"net/http"
	"training.com/stock_trading_app/models"
	"training.com/stock_trading_app/repositories"
)

type CustomersService struct {
	customersRepository *repositories.CustomersRepository
}

func NewCustomersService(customersRepository *repositories.CustomersRepository) *CustomersService {
	return &CustomersService{
		customersRepository: customersRepository,
	}
}

func (cs CustomersService) CreateCustomer(customer *models.Customer) (*models.Customer, *models.ResponseError) {
	responseErr := validateCustomer(customer)
	if responseErr != nil {
		return nil, responseErr
	}

	return cs.customersRepository.CreateCustomer(customer)
}


func (cs CustomersService) LoginCustomer(email string,password string) *models.ResponseError {
	customer,err := cs.customersRepository.GetCustomerByEmail(email)
	if err != nil {
		return err
	}
	if customer.Password != password {
		return &models.ResponseError{
			Message: "Invalid password",
			Status:  http.StatusUnauthorized,
		}
	}
	return nil
}

func validateCustomer(customer *models.Customer) *models.ResponseError {
	if customer.FirstName == "" {
		return &models.ResponseError{
			Message: "Invalid first name",
			Status:  http.StatusBadRequest,
		}
	}

	if customer.LastName == "" {
		return &models.ResponseError{
			Message: "Invalid last name",
			Status:  http.StatusBadRequest}
	}

	return nil
}

func validateCustomerId(customerId string) *models.ResponseError {
	if customerId == "" {
		return &models.ResponseError{
			Message: "Invalid customer ID",
			Status:  http.StatusBadRequest,
		}
	}

	return nil
}
