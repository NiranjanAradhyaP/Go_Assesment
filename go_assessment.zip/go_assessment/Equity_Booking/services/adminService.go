package services

import (
	"net/http"
	"training.com/stock_trading_app/models"
	"training.com/stock_trading_app/repositories"
)

type AdminsService struct {
	adminsRepository *repositories.AdminsRepository
}

func NewAdminsService(adminsRepository *repositories.AdminsRepository) *AdminsService {
	return &AdminsService{
		adminsRepository: adminsRepository,
	}
}

func (cs AdminsService) CreateAdmin(admin *models.Admin) (*models.Admin, *models.ResponseError) {
	responseErr := validateAdmin(admin)
	if responseErr != nil {
		return nil, responseErr
	}

	return cs.adminsRepository.CreateAdmin(admin)
}

// func (cs AdminsService) UpdateAdmin(admin *models.Admin) *models.ResponseError {
// 	responseErr := validateAdminId(admin.ID)
// 	if responseErr != nil {
// 		return responseErr
// 	}

// 	responseErr = validateAdmin(admin)
// 	if responseErr != nil {
// 		return responseErr
// 	}

// 	return cs.adminsRepository.UpdateAdmin(admin)
// }

// func (cs AdminsService) DeleteAdmin(adminId string) *models.ResponseError {
// 	responseErr := validateAdminId(adminId)
// 	if responseErr != nil {
// 		return responseErr
// 	}

// 	return cs.adminsRepository.DeleteAdmin(adminId)
// }

// func (cs AdminsService) GetAdmin(adminId string) (*models.Admin, *models.ResponseError) {
// 	responseErr := validateAdminId(adminId)
// 	if responseErr != nil {
// 		return nil, responseErr
// 	}

// 	admin, responseErr := cs.adminsRepository.GetAdmin(adminId)
// 	if responseErr != nil {
// 		return nil, responseErr
// 	}

// 	results, responseErr := cs.resultsRepository.GetAllAdminsResults(adminId)
// 	if responseErr != nil {
// 		return nil, responseErr
// 	}

// 	admin.Results = results

// 	return admin, nil
// }

// func (cs AdminsService) GetAdminsBatch(country string, year string) ([]*models.Admin, *models.ResponseError) {
// 	if country != "" && year != "" {
// 		return nil, &models.ResponseError{
// 			Message: "Only one parameter, country or year, can be passed",
// 			Status:  http.StatusBadRequest,
// 		}
// 	}

// 	if country != "" {
// 		return cs.adminsRepository.GetAdminsByCountry(country)
// 	}

// 	if year != "" {
// 		intYear, err := strconv.Atoi(year)
// 		if err != nil {
// 			return nil, &models.ResponseError{
// 				Message: "Invalid year",
// 				Status:  http.StatusBadRequest,
// 			}
// 		}

// 		currentYear := time.Now().Year()
// 		if intYear < 0 || intYear > currentYear {
// 			return nil, &models.ResponseError{
// 				Message: "Invalid year",
// 				Status:  http.StatusBadRequest,
// 			}
// 		}

// 		return cs.adminsRepository.GetAdminsByYear(intYear)
// 	}

// 	return cs.adminsRepository.GetAllAdmins()
// }

func (cs AdminsService) LoginAdmin(email string,password string) *models.ResponseError {
	admin,err := cs.adminsRepository.GetAdminByEmail(email)
	if err != nil {
		return err
	}
	if admin.Password != password {
		return &models.ResponseError{
			Message: "Invalid password",
			Status:  http.StatusUnauthorized,
		}
	}
	return nil
}

func validateAdmin(admin *models.Admin) *models.ResponseError {
	if admin.FirstName == "" {
		return &models.ResponseError{
			Message: "Invalid first name",
			Status:  http.StatusBadRequest,
		}
	}

	if admin.LastName == "" {
		return &models.ResponseError{
			Message: "Invalid last name",
			Status:  http.StatusBadRequest}
	}

	return nil
}

func validateAdminId(adminId string) *models.ResponseError {
	if adminId == "" {
		return &models.ResponseError{
			Message: "Invalid admin ID",
			Status:  http.StatusBadRequest,
		}
	}

	return nil
}
